# Проект: Путешествие по России

### Обзор
* Интро
* Figma
* Картинки

**Интро**

Здесь будет проект о путешествии по России.
В Фигме разместили макет, в котором видно, как проект должен выглядеть на самых распространённых разрешениях экранов.

**Figma**

* [Ссылка на макет в Figma](https://www.figma.com/file/5S2WSbEFL6awjVWJ0NWL8Q/Sprint-3_-Russia-_-desktop-mobile?node-id=28503%3A0)

Используются HTML и CSS, а так же их внутренности :D

https://hornyferret.github.io/russian-travel-bootcamp/
